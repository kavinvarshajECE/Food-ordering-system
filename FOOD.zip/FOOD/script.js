function orderNow() {
    alert("Thank you for your order! We are processing it now.");
}

function showPrices() {
    alert("Here are the prices for our products...");
}

function showSpecials() {
    alert("Check out our special offers...");
}

document.addEventListener("DOMContentLoaded", function() {
    const contactForm = document.getElementById("contactForm");

    contactForm.addEventListener("submit", function(event) {
        event.preventDefault(); // Prevent the default form submission

        // Collect form data
        const queryType = document.getElementById("query").value;
        const name = document.getElementById("name").value;
        const email = document.getElementById("email").value;
        const phone = document.getElementById("pho").value;
        const isMember = document.querySelector('input[name="eligible"]:checked')?.value;
        const message = document.getElementById("message").value;

        // Form validation
        if (!name || !email || !phone || !isMember || !message) {
            alert("Please fill in all fields.");
            return;
        }

        // Process form data (for now, just display an alert)
        alert(`Query Type: ${queryType}
Name: ${name}
Email: ${email}
Phone: ${phone}
Member: ${isMember}
Message: ${message}`);

        // Reset the form
        contactForm.reset();
    });
});
